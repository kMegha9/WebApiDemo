﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Demon.Models;

namespace Demon.Controllers
{
    public class custOMERsController : ApiController
    {
        private Sep19CHNEntities db = new Sep19CHNEntities();

        // GET: api/custOMERs
        public IQueryable<custOMER> GetcustOMERs()
        {
            return db.custOMERs;
        }

        // GET: api/custOMERs/5
        [ResponseType(typeof(custOMER))]
        public IHttpActionResult GetcustOMER(int id)
        {
            custOMER custOMER = db.custOMERs.Find(id);
            if (custOMER == null)
            {
                return NotFound();
            }

            return Ok(custOMER);
        }

        // PUT: api/custOMERs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutcustOMER(int id, custOMER custOMER)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != custOMER.custid)
            {
                return BadRequest();
            }

            db.Entry(custOMER).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!custOMERExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/custOMERs
        [ResponseType(typeof(custOMER))]
        public IHttpActionResult PostcustOMER(custOMER custOMER)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.custOMERs.Add(custOMER);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (custOMERExists(custOMER.custid))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = custOMER.custid }, custOMER);
        }

        // DELETE: api/custOMERs/5
        [ResponseType(typeof(custOMER))]
        public IHttpActionResult DeletecustOMER(int id)
        {
            custOMER custOMER = db.custOMERs.Find(id);
            if (custOMER == null)
            {
                return NotFound();
            }

            db.custOMERs.Remove(custOMER);
            db.SaveChanges();

            return Ok(custOMER);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool custOMERExists(int id)
        {
            return db.custOMERs.Count(e => e.custid == id) > 0;
        }
    }
}